package GUI;

public class Driver {
	public static void main (String[] args) {
		GUI caltrain = new GUI();
		caltrain.start();
	}
}
